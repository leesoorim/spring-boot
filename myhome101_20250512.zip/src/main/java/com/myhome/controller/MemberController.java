package com.myhome.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.myhome.dto.MemberDto;
import com.myhome.dto.MycodeDto;
import com.myhome.service.MemberService;

@Controller
public class MemberController {

	@Autowired
	MemberService memberService;
	
	@GetMapping("memberWrite")
	public String memberWrite( MycodeDto mycodeDto
							  ,ModelMap model) throws Exception {
		
		mycodeDto.setCodgp("H");
		List<?> list =  memberService.selectMycodeList(mycodeDto);
		model.addAttribute("codeList", list);
		
		return "member/memberWrite";
	}
	
	@PostMapping("useridCheck")
	@ResponseBody
	public String useridCheck(String userid) throws Exception {
		
		String msg = "1";
		// 첫 글자 영문자 / 특수문자(-_#) / 한글 허용 문제
		// 정규표현식 사용
		String pattern = "^[a-zA-Z]{1}[a-zA-Z0-9_\\-#]{5,11}";
		boolean result = userid.matches(pattern);  // true or false
		
		if( result == false ) {
			msg = "2";
		} else {
			// 중복 아이디 체크
			int cnt = memberService.selectMemeberUserid(userid);
			if( cnt > 0 ) msg = "3";
		}
		return msg;
	}
	
	@PostMapping("memberInsert")
	@ResponseBody
	public String memberInsert(MemberDto dto) throws Exception {
		
		// 저장완료, 저장실패, 중복체크
		String msg = "1";
		
		// 아이디 중복체크
		int cnt = memberService.selectMemeberUserid(dto.getUserid());
		
		if(cnt > 0) {
			msg = "2";
		} else {
			// 101,102,103
			System.out.println( "hobby :::::::::: " + dto.getHobby() );
			
			// 저장 처리
			int result = memberService.insertMember(dto);
			if( result == 0 ) msg = "3";
		}
		return msg;
	}
	
}









