package com.myhome.mapper;

import java.util.List;
import org.apache.ibatis.annotations.Mapper;

import com.myhome.dto.MemberDto;
import com.myhome.dto.MycodeDto;

@Mapper
public interface MemberMapper {

	List<?> selectMycodeList(MycodeDto dto);
	int selectMemeberUserid(String userid);
	int insertMember(MemberDto dto);

}
