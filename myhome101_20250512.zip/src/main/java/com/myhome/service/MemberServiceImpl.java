package com.myhome.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.myhome.dto.MemberDto;
import com.myhome.dto.MycodeDto;
import com.myhome.mapper.MemberMapper;

@Service
public class MemberServiceImpl implements MemberService {

	@Autowired
	MemberMapper mapper;
	
	@Override
	public List<?> selectMycodeList(MycodeDto dto) throws Exception {
		return mapper.selectMycodeList(dto);
	}

	@Override
	public int selectMemeberUserid(String userid) throws Exception {
		return mapper.selectMemeberUserid(userid);
	}

	@Override
	public int insertMember(MemberDto dto) throws Exception {
		return mapper.insertMember(dto);
	}

}
