package com.myhome.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.myhome.dto.DataDto;
import com.myhome.mapper.DataMapper;

@Service
public class DataServiceImpl implements DataService {

	@Autowired
	DataMapper mapper;
	
	@Override
	public int insertDataboard(DataDto dto) throws Exception {
		return mapper.insertDataboard(dto);
	}

}
