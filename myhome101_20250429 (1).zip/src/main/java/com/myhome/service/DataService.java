package com.myhome.service;

import com.myhome.dto.DataDto;

public interface DataService {

	int insertDataboard(DataDto dto) throws Exception;
	
}
