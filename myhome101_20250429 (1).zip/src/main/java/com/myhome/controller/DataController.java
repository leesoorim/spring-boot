package com.myhome.controller;

import java.io.File;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.myhome.dto.DataDto;
import com.myhome.service.DataService;


@Controller
public class DataController {

	@Autowired
	DataService dataService;
	
	@GetMapping("dataWrite")
	public String dataWrite() {
		
		return "board/dataWrite";
	}
	
	@PostMapping("dataBoardInsert")
	@ResponseBody
	public String insertDataBoard(   MultipartHttpServletRequest request
									,DataDto dto ) 
											throws Exception {
		
		String path= "C:/Users/hi_guri/git/spring102/myhome101/src/main/webapp/data";
		
		// 넘어온 데이터를 가져옴
		Map map = request.getFileMap();
		
		// Map의 키값(들)을 가져옴
		Iterator it = map.entrySet().iterator();
		
		// 키값이 있는 위치로 커서를 내려보냄
		Entry entry = (Entry) it.next();
		
		
		// 해당 위치에서 파일의 정보들을 가져온다. 
		MultipartFile file = (MultipartFile)entry.getValue();
		
		String filename = file.getOriginalFilename();
		
		String filepath = path+"/"+filename;
		
		System.out.println("이름 : "+filename);
		System.out.println("크기 : "+file.getSize());
		System.out.println("용량 : "+file.getBytes());
		System.out.println("종류 : "+file.getContentType());
		System.out.println("이름 : "+file.getName());

		// {실 저장} / {파일 카피}
		file.transferTo(new File(filepath));
		
		String dirname = "/webapp/data";
		
		dto.setFilepath(dirname);
		dto.setFilename(filename);
		dto.setFilesize(Integer.parseInt(file.getSize()+""));
		
		int result = dataService.insertDataboard(dto);
		return "1";
	}
	
	
	
	
}
