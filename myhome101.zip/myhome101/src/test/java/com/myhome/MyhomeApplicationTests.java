package com.myhome;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyhomeApplicationTests {

	@Test
	void contextLoads() {
	}

}
