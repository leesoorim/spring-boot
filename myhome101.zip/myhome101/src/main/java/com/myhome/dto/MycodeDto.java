package com.myhome.dto;

import lombok.Data;

@Data
public class MycodeDto {

	
	int codid = 0;
	String codnm = "";
	String codgp = "";
	
	public int getCodid() {
		return codid;
	}
	public void setCodid(int codid) {
		this.codid = codid;
	}
	public String getCodnm() {
		return codnm;
	}
	public void setCodnm(String codnm) {
		this.codnm = codnm;
	}
	public String getCodgp() {
		return codgp;
	}
	public void setCodgp(String codgp) {
		this.codgp = codgp;
	}
}
