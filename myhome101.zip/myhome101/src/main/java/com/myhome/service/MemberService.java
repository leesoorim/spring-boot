package com.myhome.service;

import java.util.List;

import com.myhome.dto.MycodeDto;

public interface MemberService {

	/**
	 * 코드 목록 출력
	 * @param dto
	 * @return
	 * @throws Exception
	 */
	List<?> selectMycodeList(MycodeDto dto) throws Exception;

	/**
	 * 아이디 중복 체크
	 * @param userid
	 * @return
	 */
	int selectMemberUserid(String userid) throws Exception;
	
}
